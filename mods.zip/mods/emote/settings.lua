

emote.settings = {
    announce_in_chat = minetest.settings:get_bool("emote.announce_in_chat", false),
}
