# Intllib tool

please consider using the intllib tool to update locale files:

```../../intllib/tools/xgettext.sh ../**/*.lua```

make sure you are in `3d_armor` derectory before running this command
