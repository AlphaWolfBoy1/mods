3D Armor - Visible Player Armor
===============================

License Source Code: Copyright (C) 2013-2023 Stuart Jones - LGPL v2.1

Armor Textures: Copyright (C) 2017-2023 davidthecreator - CC-BY-SA 3.0

Special credit to Jordach and MirceaKitsune for providing the default 3d character model.

New armor/shield textures CC-BY-SA 3.0 / davidthecreator / https://forum.minetest.net/viewtopic.php?f=11&t=4654&start=800#p356448
